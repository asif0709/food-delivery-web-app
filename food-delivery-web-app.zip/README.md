# Food Delivery Web Application

A small portfolio implementation of a food-delivery workflow using a Java HTTP server, MySQL and a responsive HTML/CSS/JavaScript frontend.

## Features
- Menu loaded from MySQL
- Add items to a browser cart
- Basic order submission
- Java backend endpoint for menu and orders
- SQL schema and sample menu data
- Responsive frontend

## Stack
Java 17 · MySQL · JDBC · HTML5 · CSS3 · JavaScript · Maven

## Run
1. Install Java 17+, Maven and MySQL.
2. Run `sql/schema.sql` in MySQL.
3. Set `DB_URL`, `DB_USER` and `DB_PASSWORD` if your local database settings differ.
4. Run `mvn compile exec:java`.
5. Open `http://localhost:8080`.

This is a portfolio implementation created from the project scope described in my resume. Database credentials are intentionally kept outside the repository.
